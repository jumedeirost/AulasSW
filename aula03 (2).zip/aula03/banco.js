function dados(){

    const ds = [
                   {id:1,login:"bruno",senha:"12345",email:"bruno@gmail.com"},
                   {id:2,login:"ringo",senha:"2222",email:"ringo@gmail.com"},
                   {id:3,login:"paul",senha:"5555",email:"paul@gmail.com"}
               ]
               const dados = JSON.stringify(ds) //passa para o formato JSON - textp
               localStorage.setItem("nome", dados) // insere no armazenamento do navegador2
    return dados
}
function removerbd(){
    localStorage.removeItem("nome")
}

